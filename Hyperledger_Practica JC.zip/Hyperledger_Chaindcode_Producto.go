package main

import (
	"encoding/json"
	"fmt"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// SmartContract define la estructura de este contrato inteligente
type SmartContract struct {
	contractapi.Contract
}

// Producto representa la estructura básica de un producto en la cadena de suministro
type Producto struct {
	ID                string         `json:"id"`
	Nombre            string         `json:"nombre"`
	Estado            string         `json:"estado"`
	LocalizacionActual string        `json:"localizacionActual"`
	Historial         []HistorialItem `json:"historial"`
}

// HistorialItem define cada entrada en el historial de un producto
type HistorialItem struct {
	Estado      string `json:"estado"`
	Localizacion string `json:"localizacion"`
	Timestamp   string `json:"timestamp"` // Considera el formato de fecha/tiempo que prefieras
}

// InicializarProducto añade un nuevo producto al ledger con estado inicial
func (s *SmartContract) InicializarProducto(ctx contractapi.TransactionContextInterface, id string, nombre string) error {
	producto := Producto{
		ID:                id,
		Nombre:            nombre,
		Estado:            "Fabricado",
		LocalizacionActual: "Planta de Fabricación",
		Historial:         []HistorialItem{},
	}

	productoJSON, err := json.Marshal(producto)
	if err != nil {
		return err
	}

	return ctx.GetStub().PutState(id, productoJSON)
}

// ActualizarEstado actualiza el estado y localización del producto y añade el evento al historial
func (s *SmartContract) ActualizarEstado(ctx contractapi.TransactionContextInterface, id string, nuevoEstado string, nuevaLocalizacion string, timestamp string) error {
	productoJSON, err := ctx.GetStub().GetState(id)
	if err != nil {
		return fmt.Errorf("error al leer el producto: %s", err.Error())
	}
	if productoJSON == nil {
		return fmt.Errorf("el producto %s no existe", id)
	}

	var producto Producto
	err = json.Unmarshal(productoJSON, &producto)
	if err != nil {
		return err
	}

	// Actualiza el estado y localización actual del producto
	producto.Estado = nuevoEstado
	producto.LocalizacionActual = nuevaLocalizacion

	// Añade el cambio al historial del producto
	historialItem := HistorialItem{
		Estado:      nuevoEstado,
		Localizacion: nuevaLocalizacion,
		Timestamp:   timestamp,
	}
	producto.Historial = append(producto.Historial, historialItem)

	productoActualizadoJSON, err := json.Marshal(producto)
	if err != nil {
		return err
	}

	// Guarda el producto actualizado en el ledger
	return ctx.GetStub().PutState(id, productoActualizadoJSON)
}

// IniciarTransporte prepara un producto para su transporte y lo marca como "Espera de Transporte"
func (s *SmartContract) IniciarTransporte(ctx contractapi.TransactionContextInterface, id string, timestamp string) error {
	return s.ActualizarEstado(ctx, id, "Espera de Transporte", "Planta de Fabricación", timestamp)
}

// ComenzarTransporte cambia el estado del producto a "En Tránsito" y actualiza su localización inicial
func (s *SmartContract) ComenzarTransporte(ctx contractapi.TransactionContextInterface, id string, localizacionInicio string, timestamp string) error {
	return s.ActualizarEstado(ctx, id, "En Tránsito", localizacionInicio, timestamp)
}

// ActualizarTransporte permite actualizar el estado y localización del producto durante su transporte
func (s *SmartContract) ActualizarTransporte(ctx contractapi.TransactionContextInterface, id string, nuevoEstado string, nuevaLocalizacion string, timestamp string) error {
	return s.ActualizarEstado(ctx, id, nuevoEstado, nuevaLocalizacion, timestamp)
}

// FinalizarTransporte marca el producto como "Entregado al Minorista"
func (s *SmartContract) FinalizarTransporte(ctx contractapi.TransactionContextInterface, id string, localizacionFinal string, timestamp string) error {
	return s.ActualizarEstado(ctx, id, "Entregado al Minorista", localizacionFinal, timestamp)
}

func main() {
	chaincode, err := contractapi.NewChaincode(&SmartContract{})
	if err != nil {
		fmt.Printf("Error al crear el chaincode: %s", err.Error())
		return
	}

	if err := chaincode.Start(); err != nil {
		fmt.Printf("Error al iniciar el chaincode: %s", err.Error())
	}
}
