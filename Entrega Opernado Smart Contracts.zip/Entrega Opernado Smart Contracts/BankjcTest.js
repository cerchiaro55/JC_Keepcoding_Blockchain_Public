// SPDX-License-Identifier: MIT
const { expect } = require("chai");

describe("Bank Contract", function () {
  let Bank;
  let bank;
  let owner;
  let user1;
  let user2;

  const initialInterestRate = 5; // Initial interest rate

  beforeEach(async function () {
    [owner, user1, user2] = await ethers.getSigners();
    Bank = await ethers.getContractFactory("Bank");
    bank = await Bank.deploy(initialInterestRate);
    await bank.deployed();
  });

  it("Should set the owner as admin", async function () {
    expect(await bank.admin()).to.equal(owner.address);
  });

  it("Should allow the owner to set the interest rate", async function () {
    const newInterestRate = 7;
    await bank.connect(owner).setInterestRate(newInterestRate);
    expect(await bank.interestRate()).to.equal(newInterestRate);
  });

  it("Should not allow non-admin to set the interest rate", async function () {
    const newInterestRate = 7;
    await expect(bank.connect(user1).setInterestRate(newInterestRate)).to.be.revertedWith("UNAUTHORIZED");
  });

  it("Should allow users to deposit Ether", async function () {
    const depositAmount = ethers.utils.parseEther("1");
    await bank.connect(user1).deposit({ value: depositAmount });
    expect(await bank.balances(user1.address)).to.equal(depositAmount);
  });

  it("Should not allow users to withdraw more than their balance", async function () {
    const depositAmount = ethers.utils.parseEther("1");
    await bank.connect(user1).deposit({ value: depositAmount });
    await expect(bank.connect(user1).withdraw(depositAmount.add(1))).to.be.revertedWith("INSUFFICIENT_BALANCE");
  });

  it("Should calculate interest correctly", async function () {
    const depositAmount = ethers.utils.parseEther("1");
    await bank.connect(user1).deposit({ value: depositAmount });

    // Increase time to simulate interest accumulation
    await network.provider.send("evm_increaseTime", [12 * 30 * 24 * 60 * 60]); // 12 months

    const interestAmount = await bank.calculateInterest(user1.address);
    expect(interestAmount).to.be.gt(0);
  });

  it("Should allow users to withdraw with interest", async function () {
    const depositAmount = ethers.utils.parseEther("1");
    await bank.connect(user1).deposit({ value: depositAmount });

    // Increase time to simulate interest accumulation
    await network.provider.send("evm_increaseTime", [12 * 30 * 24 * 60 * 60]); // 12 months

    const initialBalance = await user1.getBalance();
    const interestAmount = await bank.calculateInterest(user1.address);

    await bank.connect(user1).withdraw(depositAmount);
    const finalBalance = await user1.getBalance();

    expect(finalBalance).to.be.gt(initialBalance.add(interestAmount));
  });

  it("Should not allow users to withdraw without sufficient balance", async function () {
    await expect(bank.connect(user1).withdraw(ethers.utils.parseEther("1"))).to.be.revertedWith("INSUFFICIENT_BALANCE");
  });
});
